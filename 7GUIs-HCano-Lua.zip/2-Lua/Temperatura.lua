---------------------------------
-- Temperatura.lua
-- Hern�n Cano Mart�nez
-- Ene-2018
---------------------------------

package.cpath = "?.dll;?53.dll;lua533/?.dll;lua533/?53.dll;"   -- [in Windows]

require ( "iuplua" )

-- iup.key_open()  -- is obsolete and not necessary anymore in since IUP 3.0 RC 3 .

-- ***************************************************************************

-- los controles que usaremos en nuestro formulario

txtC = iup.text   { value="0"          , expand='NO', floating='NO', rastersize = "70"   , cx="030", cy= "30", font ="Courier New, 10", NC='10', ACTIVE='YES', ALIGNMENT='ACENTER' }
lblC = iup.label  { title = "Celsius =", expand='NO', floating='NO', rastersize = "85x25", cx="110", cy= "27", font ="Courier New, 10" }  -- size  in pixels

txtF = iup.text   { value="0"          , expand='NO', floating='NO', rastersize = "70"   , cx="200", cy= "30", font ="Courier New, 10", NC='10', ACTIVE='YES', ALIGNMENT='ACENTER' }
lblF = iup.label  { title = "Farenheit", expand='NO', floating='NO', rastersize = "85x25", cx="280", cy= "27", font ="Courier New, 10" }  -- size  in pixels

btnC = iup.button { title = "Cerrar"   , expand='NO', floating='NO', rastersize = "75x25", cx="200", cy="100", font ="Segoe IU, 9", TIP='Haga click para cerrar' }

-- ***************************************************************************

-- el Contenedor de controles

vArea = iup.cbox{ expand='NO', floating='NO', size = "450x200",
  txtC, lblC, txtF, lblF, --btnC,
  nil
}

-- El formulario

frmTemperatura = iup.dialog{ expand='NO', floating='NO', 
  vArea,
  title = "Temperatura", 
  size = "300x100"
}

-- ********************************** Callbacks *****************************************

function btnC:action()
  -- Exits the main loop
  return iup.CLOSE  
end


function txtC:action(t, new_value)

   if new_value and tonumber(new_value) then
      local nNum = tonumber(new_value)
      txtF.value = nNum * (9/5) + 32
   end
   
end


function txtF:action(t, new_value)

   if new_value and tonumber(new_value) then
      local nNum = tonumber(new_value) 
      txtC.value = (nNum - 32) * (5/9)
   end
   
end

 
--------------------------------------------

-- Ahora s�: mostremos el formulario

frmTemperatura:showxy(iup.CENTER,iup.CENTER)

-- to be able to run this script inside another context
-- if (iup.MainLoopLevel()==0) then
if (not iup.MainLoopLevel or iup.MainLoopLevel()==0) then
  iup.MainLoop()
end

----------------------------------------------
