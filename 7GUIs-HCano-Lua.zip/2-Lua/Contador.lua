---------------------------------
-- Contador.lua
---------------------------------

package.cpath = "?.dll;?53.dll;lua533/?.dll;lua533/?53.dll;"   -- [in Windows]

require ( "iuplua" )

---------------------------------

txtContador = iup.text   { value="0"         , expand='NO', floating='NO', rastersize = "70"   , cx="100", cy="25", font ="Courier New, 10", NC='0', ACTIVE='no', ALIGNMENT='ACENTER' }

btnContador = iup.button { title = "Contador", expand='NO', floating='NO', rastersize = "75x25", cx="200", cy="25", font ="Segoe IU, 9", TIP='Haga click en este bot�n' }

---------------------------------

-- ********************************** Callbacks *****************************************

function btnContador:action()

   local nNum = 0 
   if txtContador.value then
      nNum = tonumber(txtContador.value)
      txtContador.value = nNum+1
   else
      txtContador.value =  1
   end
					 
end

-- ***************************************************************************

vArea = iup.cbox{ expand='NO', floating='NO', size = "450x200",
  txtContador, btnContador,
  nil
}
frmContador = iup.dialog{ expand='NO', floating='NO', 
  vArea,
  title = "Contador", 
  size = "250x100"
}

--------------------------------------------

frmContador:showxy(iup.CENTER,iup.CENTER)

-- to be able to run this script inside another context
if (iup.MainLoopLevel()==0) then
  iup.MainLoop()
  iup.Close()
end

--