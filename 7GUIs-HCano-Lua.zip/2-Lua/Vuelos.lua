---------------------------------
-- Vuelos.lua
-- Hern�n Cano Mart�nez
-- Ene-2018
---------------------------------

package.cpath = "?.dll;?53.dll;lua533/?.dll;lua533/?53.dll;"   -- [in Windows]

require ( "iuplua" )

-- ***************************************************************************

-- los controles que usaremos en nuestro formulario

cmbC = iup.list   { value=1           , expand='NO', floating='NO', rastersize ="150"   , cx="030", cy="000", font ="Courier New, 10", NC='10', ACTIVE='YES', ALIGNMENT='ACENTER', " s�lo de ida   ", " ida y regreso ", dropdown="Yes" --[[, valuechanged_cb = toolstyle_valuechanged_cb]]}

txt1 = iup.text   { value="0"         , expand='NO', floating='NO', rastersize ="150"   , cx="030", cy="050", font ="Courier New, 10", NC='10', ACTIVE='YES', ALIGNMENT='ACENTER' }
txt2 = iup.text   { value="0"         , expand='NO', floating='NO', rastersize ="150"   , cx="030", cy="100", font ="Courier New, 10", NC='10', ACTIVE='YES', ALIGNMENT='ACENTER' }

btnB = iup.button { title = "Reservar", expand='NO', floating='NO', rastersize ="155x35", cx="030", cy="150", font ="Segoe IU, 9", TIP='Haga click para reservar' }

-- ***************************************************************************

-- el Contenedor de controles

vArea = iup.cbox{ expand='NO', floating='NO', size = "250x300",
  cmbC, txt1, txt2, btnB,
  nil
}

-- El formulario

frmVuelos = iup.dialog{ expand='NO', floating='NO', 
  vArea,
  title = "Reserva de Vuelos", 
  size = "150x150"
}

-- ********************************** Callbacks *****************************************

function btnC_action()
  -- Exits the main loop
  return iup.CLOSE  
end


function txtC_action(t, new_value)

   if new_value and tonumber(new_value) then
      local nNum = tonumber(new_value)
      txtF.value = nNum * (9/5) + 32
   end
   
end

function toolstyle_valuechanged_cb(self)
  local value = self.value
  iup.SetAttribute(iup.GetDialog(self), "TOOLSTYLE", value)
end

function txtF_action(t, new_value)

   if new_value and tonumber(new_value) then
      local nNum = tonumber(new_value) 
      txtC.value = (nNum - 32) * (9/5)
   end
   
end

 
--------------------------------------------

-- Ahora s�: mostremos el formulario

frmVuelos:showxy(iup.CENTER,iup.CENTER)

-- to be able to run this script inside another context
-- if (iup.MainLoopLevel()==0) then
if (not iup.MainLoopLevel or iup.MainLoopLevel()==0) then
  iup.MainLoop()
end

----------------------------------------------
