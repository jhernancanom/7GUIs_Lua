print("----------------------------------------------")
print("----------------LSQLITE3-----------------------")
local sqlite3=require("lsqlite3")
for k, v in pairs(sqlite3) do
	print (k, v)
end
print("----------------------------------------------")
print("    Lua Version : ".._VERSION)
print("SQLite3 Version : "..sqlite3.version())
print("lsqlite3 Version: "..sqlite3.lversion())
print("----------------------------------------------")

